<script>
	location.href="{{route('home')}}"
</script>