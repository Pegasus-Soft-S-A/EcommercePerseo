<script>
	location.href="<?php echo e(route('home')); ?>"
</script><?php /**PATH C:\laragon\www\tienda\resources\views/errors/405.blade.php ENDPATH**/ ?>