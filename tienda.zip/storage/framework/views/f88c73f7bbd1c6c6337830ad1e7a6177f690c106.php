<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Documento: <?php echo e($documentoid); ?></h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body gry-bg px-3 pt-3">
    <div class="col-lg-12 text-center">
        <table class="table">
            <thead>
                <th width="30%">Tipo</th>
                <th width="30%">Emision</th>
                <th width="30%">Valor</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalle->tipo); ?></td>
                    <td><?php echo e($detalle->emision); ?></td>
                    <td><?php echo e($detalle->importe); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\laragon\www\tienda\resources\views/frontend/cliente/detalle_documento.blade.php ENDPATH**/ ?>