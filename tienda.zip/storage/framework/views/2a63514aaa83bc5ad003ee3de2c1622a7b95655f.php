<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-12 mx-auto">
        <h6 class="fw-600">Configuracion Pagina de Inicio</h6>

        
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Slider de Inicio</h6>
            </div>
            <form action="<?php echo e(route('business_settings.update_inicio')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    

                    <div class="form-group">
                        <label>Fotos y Enlaces</label>

                        <div class="home-slider-target">
                            <?php if(get_setting('home_slider')): ?>
                            <?php $__currentLoopData = json_decode(get_setting('home_slider')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="row gutters-5">
                                <div class="col-md-3">
                                    <label>Imagen</label>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input type="file" name="imagenes[]" class="selected-files" value=""
                                                accept="image/png">
                                            <small class="text-muted">Imagen 1000x500.png</small>
                                        </div>
                                    </div>
                                    <div class="position-relative">
                                        <input type="hidden" value="<?php echo e($slider->imagen); ?>" name="imagen[]">
                                        <img class="img-fit lazyload mx-auto "
                                            src=" data:image/jpg;base64,<?php echo e($slider->imagen); ?>" alt="">
                                    </div>
                                    <br>
                                </div>
                                <div class="col-md-3">
                                    <label>Link</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="http://" name="links[]"
                                            autocomplete="off" value="<?php echo e($slider->link); ?>">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <label>Fecha Inicio</label>
                                    <div class="form-group">
                                        <input type="date" class="form-control" name="inicio[]" autocomplete="off"
                                            value="<?php echo e($slider->inicio); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <label>Fecha Fin</label>
                                    <div class="form-group">
                                        <input type="date" class="form-control" name="fin[]" autocomplete="off"
                                            value="<?php echo e($slider->fin); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-auto">
                                    <div class="form-group">
                                        <button type="button"
                                            class="mt-4 btn btn-icon btn-circle btn-sm btn-soft-danger"
                                            data-toggle="remove-parent" data-parent=".row">
                                            <i class="las la-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <br>
                        <button type="button" class="btn btn-soft-secondary btn-sm" data-toggle="add-more" data-content='
                        <div class="row gutters-5">
                            <div class="col-md-3">
                                <label>Imagen</label>
                                <div class="form-group">
                                    <div class="input-group">
                                        <input type="file" name="imagenes[]" class="selected-files" accept="image/png"
                                        value="" >
                                        <small class="text-muted">Imagen 1000x500.png</small>
                                    </div>
                                </div>
                                <div class="file-preview box sm">
                                </div>
                            </br>
                            </div>
                            <div class="col-md-3">
                                <label>Link</label>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="http://" name="links[]">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label>Fecha Inicio</label>
                                <div class="form-group">
                                    <input type="date" class="form-control"  name="inicio[]" value="<?php echo e(date(' Y-m-d')); ?>" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <label>Fecha Fin</label>
                    <div class="form-group">
                        <input type="date" class="form-control" name="fin[]" value="<?php echo e(date('Y-m-d')); ?>" required>
                    </div>
                </div>
                <div class="col-md-auto">
                    <div class="form-group">
                        <button type="button" class="mt-4 btn btn-icon btn-circle btn-sm btn-soft-danger"
                            data-toggle="remove-parent" data-parent=".row">
                            <i class="las la-times"></i>
                        </button>
                    </div>
                </div>
        </div>' data-target=".home-slider-target">
        Agregar Nuevo
        </button>
    </div>
</div>

<div class="card-header">
    <h6 class="mb-0">Top 10</h6>
</div>
<div class="card-body">
    <div class="form-group row">
        <label class="col-md-2 col-from-label">Top <?php echo e(ucfirst(get_setting('grupo_productos'))); ?> (Max
            10)</label>
        <div class="col-md-10">
            <select name="top10_categories[]" class="form-control aiz-selectpicker" multiple data-max-options="10"
                data-live-search="true" <?php if(get_setting('top10_categories')): ?>) data-selected="[<?php echo e(implode(" ,"
                ,get_setting('top10_categories'))); ?>]" <?php endif; ?>>
                <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->$grupoid); ?>"><?php echo e($category->descripcion); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="text-right">
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </div>
</div>
</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda\resources\views/backend/paginas/inicio_edit.blade.php ENDPATH**/ ?>