<?php
	echo $array['content'];
?><?php /**PATH C:\laragon\www\tienda\resources\views/emails/test.blade.php ENDPATH**/ ?>