<?php $__env->startSection('content'); ?>

<div class="card">
    <form class="" action="" id="sort_orders" method="GET">
        <div class="card-header row gutters-5">
            <div class="col">
                <h5 class="mb-md-0 h6">Facturas</h5>
            </div>
            <div class="col-lg-3 ml-auto">
                <select class="form-control aiz-selectpicker" name="estado" id="estado">
                    <option value="">Todos</option>
                    <option value="0" <?php if(isset($estado)): ?><?php if($estado==0 ): ?> selected <?php endif; ?> <?php endif; ?>>Facturado</option>
                    <option value="1" <?php if(isset($estado)): ?><?php if($estado==1 ): ?> selected <?php endif; ?> <?php endif; ?>>En la Entrega</option>
                    <option value="2" <?php if(isset($estado)): ?><?php if($estado==2 ): ?> selected <?php endif; ?> <?php endif; ?>>Entregado</option>

                </select>
            </div>
            <div class="col-lg-3">
                <div class="form-group mb-0">
                    <input type="text" class="aiz-date-range form-control" value="<?php echo e($fecha); ?>" name="fecha"
                        placeholder="Filtrar por Fecha" data-format="DD-MM-Y" data-separator=" a "
                        data-advanced-range="true" autocomplete="off">
                </div>
            </div>
            <div class="col-lg-3">
                <div class="form-group mb-0">
                    <input type="text" class="form-control" id="busqueda" name="busqueda" <?php if(isset($busqueda)): ?>
                        value="<?php echo e($busqueda); ?>" <?php endif; ?> placeholder="Buscar por cliente" autocomplete="off">
                </div>
            </div>
            <div class="col-auto">
                <div class="form-group mb-0">
                    <button type="submit" class="btn btn-primary">Filtrar</button>
                </div>
            </div>
        </div>

        <div class="card-body">
            <table class="table aiz-table mb-0 ">
                <thead>
                    <tr>
                        <th width="25%">Secuencia</th>
                        <th data-breakpoints="md">Cliente</th>
                        <th data-breakpoints="md">Total</th>
                        <th data-breakpoints="md">Estado</th>
                        <th class="text-center" width="15%">Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $secuencial = $factura->establecimiento . ' - ' . $factura->puntoemision . ' - ' . $factura->secuencial;
                    ?>
                    <tr>
                        <td>
                            <?php echo e($secuencial); ?>

                        </td>
                        <td>
                            <?php echo e($factura->razonsocial); ?>

                        </td>
                        <td>
                            $ <?php echo e(number_format(round(($factura->total),2),2)); ?>

                        </td>
                        <td>

                            <?php if($factura->estado == 0): ?>
                            <span class="badge badge-inline badge-danger">Facturado</span>
                            <?php elseif($factura->estado == 1): ?>
                            <span class="badge badge-inline" style="background: #377dff; color:white">En la
                                Entrega</span>
                            <?php elseif($factura->estado == 2): ?>
                            <span class="badge badge-inline badge-success">Entregado</span>
                            <?php endif; ?>


                        </td>
                        <td class="text-center">
                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm"
                                href="<?php echo e(route('facturas.show', $factura->facturasid)); ?>" title="Ver">
                                <i class="las la-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="aiz-pagination text-center">
                <?php echo e($facturas->appends(request()->input())->links('pagination::bootstrap-4')); ?>

            </div>


        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="modal fade" id="order_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div id="order-details-modal-body">

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="payment_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div id="payment_modal_body">

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda\resources\views/backend/facturas.blade.php ENDPATH**/ ?>