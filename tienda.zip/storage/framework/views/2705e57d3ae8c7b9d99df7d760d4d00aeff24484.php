<?php $__env->startSection('content'); ?>

<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="align-items-center">
        <h1 class="h3">Reseñas de Productos</h1>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div class="row flex-grow-1">
            <div class="col">
                <h5 class="mb-0 h6">Reseñas de Productos</h5>
            </div>
            <div class="col-md-6 col-xl-4 ml-auto mr-0">
                <form class="" id="sort_by_rating" action="<?php echo e(route('reviews')); ?>" method="GET">
                    <div class="" style="min-width: 200px;">
                        <select class="form-control aiz-selectpicker" name="rating" id="rating"
                            onchange="filter_by_rating()">
                            <option value="">Filtrar por Valoracion</option>
                            <option value="desc">Valoracion (Mayor > Menor)</option>
                            <option value="asc">Valoracion (Menor > Mayor)</option>
                        </select>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th data-breakpoints="lg">#</th>
                    <th>Producto</th>
                    <th data-breakpoints="lg">Cliente</th>
                    <th>Valoracion</th>
                    <th data-breakpoints="lg">Comentario</th>
                    <th data-breakpoints="lg">Publicado</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($review->productosid != null && $review->clientesid != null): ?>
                <tr>
                    <td><?php echo e(($key+1) + ($reviews->currentPage() - 1)*$reviews->perPage()); ?></td>
                    <td>
                        <a href="<?php echo e(route('product',$review->productosid)); ?>"
                            target="_blank"><?php echo e($review->descripcion); ?></a>
                    </td>
                    <td><?php echo e($review->razonsocial); ?> (<?php echo e($review->email); ?>)</td>
                    <td><?php echo e($review->valoracion); ?></td>
                    <td><?php echo e($review->comentario); ?></td>
                    <td><label class="aiz-switch aiz-switch-success mb-0">
                            <input onchange="update_published(this)" value="<?php echo e($review->ecommerce_comentariosid); ?>"
                                type="checkbox" <?php if($review->estado == 1) echo "checked";?>>
                            <span class="slider round"></span></label>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($reviews->appends(request()->input())->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    function update_published(el){
            if(el.checked){
                var estado = 1;
            }
            else{
                var estado = 0;
            }
            $.post('<?php echo e(route('reviews.publicado')); ?>', {_token:'<?php echo e(csrf_token()); ?>', ecommerce_comentariosid:el.value, estado:estado}, function(data){
                if(data == 1){
                    AIZ.plugins.notify('success', 'Reseñas actualizadas correctamente ');
                }
                else{
                    AIZ.plugins.notify('danger', 'Algo salio mal');
                }
            });
        }
    function filter_by_rating(el){
            var rating = $('#rating').val();
            if (rating != '') {
                $('#sort_by_rating').submit();
            }
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda\resources\views/backend/reviews.blade.php ENDPATH**/ ?>