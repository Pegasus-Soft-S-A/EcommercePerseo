<?php $__env->startSection('panel_content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0 h6">Estado de Cartera</h5>
    </div>

    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>Secuencial</th>
                    <th>Documento</th>
                    <th data-breakpoints="md">Emision</th>
                    <th data-breakpoints="md">Vencimiento</th>
                    <th data-breakpoints="md">Dias Vencidos</th>
                    <th>Total</th>
                    <th>Saldo</th>
                    <th class="text-right">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($documento->secuencial); ?></td>
                    <td> <?php echo e($documento->documentoid); ?></td>
                    <td><?php echo e($documento->emision); ?></td>
                    <td><?php echo e($documento->vence); ?></td>
                    <td><?php echo e($documento->diasvence); ?></td>
                    <td>$<?php echo e($documento->valor); ?></td>
                    <td>$<?php echo e($documento->saldo); ?></td>
                    <td class="text-right">
                        <a href="javascript:void(0)" class="btn btn-soft-info btn-icon btn-circle btn-sm"
                            onclick="detalle_documento(<?php echo e($documento->documentoid); ?>,<?php echo e($documento->secuencia); ?>)"
                            title="Detalles del Pedido">
                            <i class="las la-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($documentos->appends(request()->input())->links('pagination::bootstrap-4')); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="modal fade" id="order_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
            <div id="detalle_documento">

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.user_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda\resources\views/frontend/cliente/estado_cartera.blade.php ENDPATH**/ ?>