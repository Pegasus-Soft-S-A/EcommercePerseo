<div class="aiz-sidebar-wrap">
    <div class="aiz-sidebar left c-scrollbar">
        <div class="aiz-side-nav-logo-wrap">
            <a href="" class="d-block text-left">
                <img class="mw-100"
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAABkCAYAAABwx8J9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFM5JREFUeNrsXUty27oShW9lfnWnmVx6BZGrPLe0gkgrsLQCxyuwvALLK5C8AisrEDNPlZUVmHfiafRWkIeWmzGt6EOAANggz6liKXHpg0+jT3ej0VAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKTg5NevX1392hHUpuzk5CSruxECx+X4ZJ6cpJZ97TWhHxIhbWwLWOtxXln0h9ZEN7JpEKFTXIxxbGvj5XxAfRnoJ+E/rT5+XyxAvf4IfalfJSqdFT/f9LPQgrwOvKikjsshIjyx7OsvoV1Kef7TGBSZHsaElddnVsiSDUIa076lgbKMTM/d6r5OhBJ3j2XlgkkvMdCPa14fK57PtaT+aTLvsqx0drS9r4l9rYDWEPo2yKq7D6XYQejyPEr9zFkGRHlbevhG+uUqMs8VhF6v0XfpQV5IN36ldVI3ubNn/nzAqKU1PNSkvlKAM/wVUVtpESz1gngSHMYE/IEUwxdSEnr+Z+zd1K2ceySP+p8zFV8YGghs9LGTQCR350leevzdP/VvPdasJ0fqcISKDJsle/FACwk9R5eJ/VGCUgdqUxZE7IMaFfSEPVUoJOAYkT+z0ReSYHMHaFkTsX8qaaQTqQ8gKe0l9KLAPnHyGtBOj/0xtLdOv0XGpP7nDaYAOCAnXfbIZ6r8vrgP9AoOUCJ1HWtSH0Fq2k3oihfKkvcwgfZ668sQpM6/sWRjEgD2ycmEnA0lKwcnd4C+BPq9b4bvn2lSn0B62k3ouYU3A6m3Gt1ApI4QO3DQ4OOcCqnRG1ofd4G2KymJOTP8zI0m9RkkyR4fGtQXInU6W4szju0m9b6PDF8K7YPMgQPyse+IlkRszoXrNo9tahGUAR1J0+Q8VOYJoyOE341Bc3hL5/v/aljHZthTbz2pO7fwOfkOSgY4JB+xkPm2AexNX/KRtD4TDuB3LikPYdI0Qu/4UOhAVBi43Cfk0CRkCtgnH2ToPUZG5kV96ZvU10zqKaTFO25MQ+6Zfh48NoiOOiSqWmiTsksngQtJkLB+a4nQzPXzn6fv/pvnvmqVtRstAwtHBWi+VGxLyh7K/4TNYxbod24F9NULmTCZzzy2d1unXPBrzwOp932G34nUeX98BN71B9NKcVbVpSwWSsITf1VBmZ5WUeiG4yKytKRBX00qxfVDVOvjMOZVBeVF1bLGDtrx00IGSYHd62cqrRyng/Gg+ShdKc62emEE4+Byz3yh3kocrwx+n+bCVcW5Na9tr+FxTep3bCQDHiAy5E5EzAR5ysJu5aVheiO2NE9OFmw8DlnZmGJU9dwtGxWmCnvFxuSkaWQOvHM4qpL5mqMXJCtD/UxNyJTey585Yz05d+Cpe89+1976tX4ZQ4paROgFoaWs9aGlsA5QSa4ZxK5fzpRdYk1Vo+6zBZn3QeSNR9U989uC0Zc5coDGFR0gQsJ98wpN6nOQegsJvSCwYwtSz6/tA+IndVJ65K2bKr+q898zfP8YZN5477xKHXYy+M58RW+Y2Ie8Vmy/v8eFcUKQOrLf3WIaTZY7k3pq+LELzHFjSJ0U1NDUqKtYxzoxeO/C9/4jUDuZkyzZ7v8SgfVDyAjnuJxWIMybQGViM0iVs3G8pu2M2ArL0P7Lk0cPC5BN6iutaEgxjgxlwNQQVBZHeb5ihhqPO1u9RfvdNRjAZ1wQaWTxFTP29H3ihzoeRaOCKROIXjlEdQ6drVsT5ZxgH71xMD0G9cnyd0zlBt5Gs71zIkWbUPs4NJlv6Uyb7cqNIRzglrYyEQREWZtK6JaeECrHNctLzwzJEwYd4AI2CZZ0dHIuYM3YbFfa9tm1EZxA9JpN6NinBExkAIQOVPXOBxbEkrqog+AQQ2UeRfLqpXNpWBB6ywk9w7S1Hj8M3lslI9lI+WFaGotLw/fT/rWoY1m8pz4O0Hfn6+zlfIAoa4MJHQBMlautApSk+IB6vHOb46+3jsoOuyb1VL+Y7uePPOchlRkneOkNJnRMLmCSKFNliyY1kcsQ53eB4DAl86zOJLgyxoaFkeuznkeZaBs89AYTOiYXCGXUmV64c8PZ0EBzYFot8FZyZzjyNPdoQJuijMH9CWLYXEK/NBTgFNPcHHCSjgmhV/HQbcpozlxe3wrUjp7Be9eqWunVULj3OAamyAQZ8CD0GpR517GwAHHB9CjND9sfsqh7kONOy+ozeeuBKm4BfvQNzZ3J/nEaQ+lf3t83MXS91fMomemOqGzTCJ0FyvTu4VDeOYVaa0cLFOzIwluoKgO2IdSE5fXZ8TTT99H91XQz1iRA8Y+qcyYBkwpzaIKYqgVKqudRJtMdhnHDPPRZwxcYcJgYSKGYlt5cVc025i2bVNBQJGzUDDhasWTSmkkn9whhOp4x1cgwlWmfhJ6VlHsgdkInz5y8EWWeabnmqzeB+MmcFKvN/dMPjppA53elh1JHTO5LEHs9iOxyHlND1+fRtTLbYpDpEhB9OQsrJhvPnHCP6Y2eyEmJfFF2JShtsnn3KepMt4VI/TGCYaM1QxW+prrd15AisQRZt/GRCdqlK5Xp/nI+AKnvGb+P3xdrkYTOSpwm7qqCVUadm2KeoyXyhD3OS2Ufart3maBE0R4m9Vkkw/iFDeI+7mi3hslxrQzDZY0y8jlQfs/DRw1t7BDf3ZoSepdCeh7blSg3eyW3UGLeQBncPseW9uqqhveouMfEg1czZ68mFlKnsaQkuj7uagekQnuXqSYkDERFA56405TQO0r+XkYqvFJT7IjhCMnQ1xczqa+Z1GO4+IXauASpe/McATfIFBLfqmLwVwMX4BDz2mpc+yYuTrY8U7Ky34+R+sxzTe4mIsQlQMAboQMV0SRCJzLHfmG7MQ8VnaGkIv301WsGfAzKqKvi2SqIEVEZS3wMVBK+QYRA6NtkjpBiu8k8+JWVFILXz6l6jQxJPyY54Lu9gfJ6xYQkexH1LRHmQcNDd4APDVl0dZN5BoFsH5lvEfsiJ3RW7PT8rdyHYqsmDd4FNjxSAfJhuzZXFnOTRrJmLgKNIQg9IBeecNZ6L9IO0IIb+rh72HBcbn1kVYdC5GVjr9uWBFk41ndlSe5jiixY/jatidInXfTvnEQ8zjS2Pw0+stDdHUbSt2dDL/0f39uZL+eDXwqognHMHnrUJAo48fyu27jNwgYs1XEnUn60iAKQITCHCB0d57Ue48yA+GhLI/HhYDgm854hmWeBcpPKjHUKydw5bvd00U2MhD5nMs8wj60EEfi9rYfZNGKn42jsMZuQejcG4hFkOI4M3k/vle5oXFqMQShiOkbow7wqGvAnYkmKo4mmsOop7ZVCEbUWZMidgczfe5H6hUjdVMn1MHqlYJp9fSX5eGBhu8YEXwWNNY4HRkjoZBFS4g7VoiYFTkR+DSJvPS5xlnovqZvWbU8wcqVgmkCY3z8gFaZHF0NeclVGv4PQHRI6VWELAcpap2S3KY6iiUPf1SQr8yziRLiyrJPUTaMWFxi10saS6djeCDznrfjIYs+zQeOb0GHQR+ihA+2AzVEzkcpSCFIMgRfYXMMrqjIfrxmbwkLBbq2kmu4wREHoQLzeD3noNkfO7jB6QEA5TS2MJTGV+diwsLl7IK0hQnrMS08gkSB0QC5ulUVCl1ZSIwwdEFhOTUHH2GoldSZz01MQVfoMQgehAy32fojMbULvd0iQ2+kVAv68dJv95FFdpF6RzOfc59A4mun+cj6AnIPQAcHKkhSlqfIgZXWD0futvAfKLKSKyzDMQScJbM5AE6k/hTRAec/8yZLMbU5NhPLQ4aWD0IEIYOOlf4nsQgyfMDVuMgyZseFJY2YbhiZifQ5xOY7+jQmTuS3xjWu8tTIrOZYACB1ooLJsfYIch3RNlVwKqbOSU0ritD3KRR76I90T4cMQpe+kSICqFrmaBzx3/gdKZrp/giSC0AH5ynJi4TlSGdNWnk2nEC6T+cjwoysUaaoEiiZVyf4mMl8ysQ8cyMCIidx2v7woF2MB43tMNpE7A0IHIlKWprhpU4Icle/ksOqzBZkT7iFmlQxPCkfTrWpVw9I99th/kmHGxNwtMf/kidN2E13MQ7fB2URo/iBz9VpCWAKyEuMG7MAHDIETUEnS2gseUIW9BijLVI8lhfxMPBci8ztLY2Cf0uwqmeH8qvehZyFr4fM1xHXjwXWfty7GqWpMdtgwG/GYKTYWVoGIbEPmNe6bb+Pbsb6+nA+Sj98XmQJA6B6QKGReuvbSe4aKkrybB4dHbToN9QRCny2WMIZeMvqp6IpDUq9L/qSReRkPPde5IHQQOhCBl073UN9aeMgUejzFCO5FipvqvJG6i7B3aEgk87KEfqW99B4k8HUeP35fLEDogGRFOdWK8tJQSW72ljm5DvhTSQ4xDF5J/VHFE9Uhw+5aIJnnhsYxDJTZtlyjoY2bjXGGpDhAMmz2xK/4zmfgDZskLqHKuymkvuYcltsImktEPpYqD9rbXCuE001Bjs8ShA6I9nyU+eUteYIc8EbmfVxDHExmJ+o1W1wiIZEMnPFZeul4gDSZkzoIHZCOWwvlOAhRkSsCrEDmtZB6SsSp7C4e8mXUkVd+FpEsTIWMXVQAoQPSlaNtXem2X96yAJnXK7fsrROxz2skcjIqTiPxyn+Dw+5jSBIIHWiecrS5vCXRTxsryGVM5NgzlyG7GVdf+0fZRZtsZeCaiXwSqxxw5jZIHYQONBBjZR6Cu2lRgtxG+WnlfVrTtZdACY+d5oe9dvKYXUZP8nyTM5aBaRMMOk3qcx4vyHQJQw7H1oBoPB1NzlSy1PTiCTof3G/awuWHlPgPInN441HJ8ionc94Wogzlnn7+Va+Rpfxv+4g7zwL/j4lu1eT516S+yQV5OR9QXgwdZUV+zJ94PcmCcQAAAABigSb2vIoeGT2fVLsva8nYqJ9z3gEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAGOrQEAAACNxcv5IFGvZ9c/q9dz/vTktQC+cfEa323obLWBjtxl/HxVjo6dgdABAACAppL5RB0vRkWkOtaEmnpqAxE5Fbg6dF5+U3dft6FSzX0QOgAAANA0IifyXKr9Ffd2YezaW9ftoKucTe6UIE/dun79Cf8ohQBGJX8sEz6JZA0lhT+vuMi/dAEcbAkfWWwLyePN7e5yaUajz1D/JPWNxt9UTljeur4se8t+9NRrFa2D0G2eCPSk1BEPJppqWIUwb9ErW5iulYDtHW3pzZ2ebIjwtKP+PCq7ErF9V+uZx3Rm8dGpboPNDZO/Cb3H1kywznqYQLKCbvaENTZXcEoURh772YHFRCGYW6mKTLf/J8vFquT7uyxrQ2FEuGSFNS75/twD+CqJHEuGGInQT4TJ0a8SbxO7jrfk4u6Ag5RyH1bC2r0sYQimut3i70Vg5+jR8uOkA04dycGzsi9La8W1jbhtTQ/ejBfRvsGjv8+Y9KVZxcsjljG1eckCIhEdbl+3RH9zMpfalxHLUlky7yogtKzN2AiWSuZLdTja2eP1kmA6veGmwmcT1stV8aWinruy+dCHmLzwAx5JcQLozuHN1gATyIAnmCziuaB2d7fCMRTuvaexL2wd5EZKly1OqdZxTup7PfUIyLxI6mqfpx4TmUvzwkvidjviwWN+o972Iq+UzOs0i3KRsS6iMPuavcYrJvRrwVtpUXjhB/Rq4mBtXjrgisuKn7e6US5qD50Xem7JUDjujJRBvliIXFg5DNlQkRS2viv8mxb47xA0tZPDiqfq7c7kniPLMbinHhGZH/TU4ZnXZpiseU9xVUXZedZFo4JcrFgX/d7zp/wMJsp+LPvQkaIr5DsSBzLVaxWhs2eek8T9Pu+QF9Na0OJP1Nt+VbrvqAK3uZgc8Vn4fPxB6hGS+U5SB5mLwEpw24oh0uE+fRNT9LPFhF5JV9W5JbQr5H6nG7SP/KQlc1wU/j2NVOgejngnFIJf8Wd6gvu05oXwO/zOfy+S+SoCQlwX2rsJv7NRVSTzdQwGCic67ZOrqMKqhe0zQiZ4TYs/mXKsHwfkZmWbfd0y1Db/HwwtHGlKrLPlzcZI6GUmfy10/Iu418+/6i1qstxq85yNl6XwuVlxO3PvfKTeHz+iuSAyfIpAznoqPlzsOML2t3ofjXsQ3P4fkZNRJ1K5yUERkJuK31GJkDl/y5VzYYRGZLlHbsF1mtIpTiSbF/r1m8yrFEuooR/Uh/GOOdqQudSzxA1BjxVy8SlmDK+knaHfwidMYe0GuQujoO7vWNvomdiz3L/l1iQlpUSUbFKcKNoX31vQZHu/PQZSZ+t0FCOZF0md+zGLlcwjzXI/hE1NBsFrerMtRvkWkUUM3xFRzFnufKJgrsoVStsHFxGgh4qRjnubD8XuoRcJ/G7fWW1pZz6ZFHIvfXQke33mWNBCeupRkvkOTx2eeTjQsbWT/FHvk0K7gonyK7921IHqYDh/HkaGKho0qSPdYasv1soyJyxqQufkk2lhIT1tkyP//6lMwZDAKCoqKpYxKRoklCmpn6eClbeK6bgLEXnMZF5cmPr5B2Re2/hP1fujmz2hTZ0WjPQBJZYVyZvWNucGPAs/ftoEmcnU+y2zsqDPDR02JXcGjD9na7jGnuWeW2O0yCnclTA5EnmnWyEP8oR/VL3NxqHQLXR7qC15sYzNfiFntCfq/d762lJAgRajQVnu+SkDxd7vqbQGcqh3qN5OdfSYvDNev90tAz4Vmg3fiCz3HVtmx0B6d+gyAkRcyad9yh7bXTOZW989sstDz49H7Xo6EheSes063ibqbUt+KoXMC22/ZmW13hr/zpagncFDBCzQO/DE5HGRcZ4ruURaCeeiAmddVFyrifrz0qWh4KNtnQMy041MbuakO9Xh3KM1O4V9H3PCMkEG6PyItz5nPV/pIrEPhU6lJS0IiRO3KcCiFzolElxtCR4lzom9JY6MjEISR7FwDLX3awQ3xaWF9paRn1SoLK22Xl32OyQyFUHypMV4XhcM3QsltO4EK/AzLvX6Wb1VDFsXdJFEPbpy9B6RRlYhuTgpylyIBHCeb0oWvt5hGJG8LyJOogQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/i/AAMA00cFqiHMcL8AAAAASUVORK5CYII="
                    class="brand-icon" alt="Tienda Perseo">

            </a>
        </div>
        <div class="aiz-side-nav-wrap">

            <ul class="aiz-side-nav-list" id="search-menu">
            </ul>
            <ul class="aiz-side-nav-list" id="main-menu" data-toggle="aiz-side-menu">
                <li class="aiz-side-nav-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="aiz-side-nav-link">
                        <i class="las la-home aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Dashboard</span>
                    </a>
                </li>

                <!-- Pedidos -->
                <li class="aiz-side-nav-item">
                    <a href="#" class="aiz-side-nav-link">
                        <i class="las la-money-bill aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Pedidos</span>
                        <span class="aiz-side-nav-arrow"></span>
                    </a>
                    <!--Submenu-->
                    <ul class="aiz-side-nav-list level-2">
                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('pedidos.index')); ?>" class="aiz-side-nav-link ">
                                <span class="aiz-side-nav-text">Pedidos</span>
                            </a>
                        </li>
                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('facturas.index')); ?>" class="aiz-side-nav-link ">
                                <span class="aiz-side-nav-text">Facturas</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Setup & Configurations -->

                <li class="aiz-side-nav-item">

                    <a href="#" class="aiz-side-nav-link">
                        <i class="las la-dharmachakra aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Sitio Web</span>
                        <span class="aiz-side-nav-arrow"></span>
                    </a>
                    <ul class="aiz-side-nav-list level-2">

                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('configuracion.general')); ?>" class="aiz-side-nav-link">
                                <span class="aiz-side-nav-text">General</span>
                            </a>
                        </li>

                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('configuracion.apariencia')); ?>" class="aiz-side-nav-link">
                                <span class="aiz-side-nav-text">Apariencia</span>
                            </a>
                        </li>

                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('configuracion.header')); ?>" class="aiz-side-nav-link">
                                <span class="aiz-side-nav-text">Encabezado</span>
                            </a>
                        </li>

                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('configuracion.footer')); ?>" class="aiz-side-nav-link">
                                <span class="aiz-side-nav-text">Pie de Pagina</span>
                            </a>
                        </li>

                        <li class="aiz-side-nav-item">
                            <a href="<?php echo e(route('configuracion.paginas')); ?>" class="aiz-side-nav-link">
                                <span class="aiz-side-nav-text">Paginas</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="aiz-side-nav-item">
                    <a href="<?php echo e(route('smtp_settings.index')); ?>" class="aiz-side-nav-link">
                        <i class="las la-at aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Configuracion SMTP</span>
                    </a>
                </li>

                <li class="aiz-side-nav-item">
                    <a href="<?php echo e(route('social_login.index')); ?>" class="aiz-side-nav-link">
                        <i class="las la-user aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Inicio Sesion Redes Sociales</span>
                    </a>
                </li>

                <li class="aiz-side-nav-item">
                    <a href="<?php echo e(route('configuracion.analytics')); ?>" class="aiz-side-nav-link">
                        <i class="las la-chart-line aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Herramientas Analiticas</span>
                    </a>
                </li>

                <li class="aiz-side-nav-item">
                    <a href="<?php echo e(route('reviews')); ?>" class="aiz-side-nav-link">
                        <i class="las la-comment aiz-side-nav-icon"></i>
                        <span class="aiz-side-nav-text">Reseñas de Productos</span>
                    </a>
                </li>

            </ul><!-- .aiz-side-nav -->
        </div><!-- .aiz-side-nav-wrap -->
    </div><!-- .aiz-sidebar -->
    <div class="aiz-sidebar-overlay"></div>
</div><!-- .aiz-sidebar --><?php /**PATH C:\laragon\www\tienda\resources\views/backend/inc/admin_sidenav.blade.php ENDPATH**/ ?>